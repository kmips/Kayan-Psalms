module.exports = {
  "globDirectory": ".",
  "globPatterns": [
    "**/*.{css,ttf,ico,png,icns,jpg,htm,html,js,json}"
  ],
  "swDest": "sw.js"
};
