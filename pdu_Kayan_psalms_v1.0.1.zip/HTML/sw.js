/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "css/sab-stylesheet.css",
    "revision": "542d53c6e818e1797c5080c4a80a02de"
  },
  {
    "url": "css/tooltipster.css",
    "revision": "3380d1b08264fc854bf34db6980d7f4f"
  },
  {
    "url": "fonts/KayanUni-Bold.ttf",
    "revision": "110374901ae97ecbb13fd1e95549e610"
  },
  {
    "url": "fonts/KayanUni-Regular.ttf",
    "revision": "52e41e5440c59982cc05a61e184a97fb"
  },
  {
    "url": "Htòn-01-001-001.html",
    "revision": "041004a81c27b25bd18f3a5424599599"
  },
  {
    "url": "Htòn-01-001-002.html",
    "revision": "6b5934f14a640b1d67c20319414046da"
  },
  {
    "url": "Htòn-01-001-003.html",
    "revision": "609afebc96b4b428e4b76757ecd1cbd8"
  },
  {
    "url": "Htòn-01-001-004.html",
    "revision": "f5b03c46021802e40d56613c81caf2d4"
  },
  {
    "url": "Htòn-01-001-005.html",
    "revision": "2450cbc2467e02a22dae07bbdb78bbcd"
  },
  {
    "url": "Htòn-01-001-006.html",
    "revision": "e729f03e4a5b8321e1d83c6e4d5ab31a"
  },
  {
    "url": "Htòn-01-001-007.html",
    "revision": "9ae7f21cf4b531ad18d64649b128f281"
  },
  {
    "url": "Htòn-01-001-008.html",
    "revision": "5f56b47333caf4a4121fe5e974ef75e3"
  },
  {
    "url": "Htòn-01-001-009.html",
    "revision": "544bf2cbf91be30e43dbe691fcf439d6"
  },
  {
    "url": "Htòn-01-001-010.html",
    "revision": "be46fd02efe216b531dd7aa32ca7cb18"
  },
  {
    "url": "Htòn-01-001-011.html",
    "revision": "676a3559675c404855c4832ab2232e15"
  },
  {
    "url": "Htòn-01-001-012.html",
    "revision": "f08c91202f6a809d40fe1d64c404e22c"
  },
  {
    "url": "icons/favicon.ico",
    "revision": "05ac73439952ff8e3eee6955e76f683f"
  },
  {
    "url": "icons/icon-128.png",
    "revision": "07dc66f671f207a310064a386e989244"
  },
  {
    "url": "icons/icon-144.png",
    "revision": "0a6b75f0f7dd25d593c5c363ef3e95d0"
  },
  {
    "url": "icons/icon-152.png",
    "revision": "d99636e003d86d0f5dd7a12fc0144c63"
  },
  {
    "url": "icons/icon-192.png",
    "revision": "7ea46c9b8b232adbcfda68bf0822170c"
  },
  {
    "url": "icons/icon-384.png",
    "revision": "b1c860ff10f82a5760b78708e1ffe291"
  },
  {
    "url": "icons/icon-512.png",
    "revision": "920eeaeb7b97a3e02b71008f7b4b1d1d"
  },
  {
    "url": "icons/icon-72.png",
    "revision": "387b3fb8928092499eb5f6fe28e7fb7e"
  },
  {
    "url": "icons/icon-96.png",
    "revision": "51a1f389dfb2937e38727c2434e6d02c"
  },
  {
    "url": "icons/icon.icns",
    "revision": "e7960d9ae69d80eb0bb3255e6b6c4452"
  },
  {
    "url": "icons/icon.ico",
    "revision": "4c4284876ab920383566acc85b0b9fe4"
  },
  {
    "url": "icons/icon.png",
    "revision": "e7960d9ae69d80eb0bb3255e6b6c4452"
  },
  {
    "url": "icons/touch-icon-ipad-retina.png",
    "revision": "93826a974ce7ebb42e8fed097646889c"
  },
  {
    "url": "icons/touch-icon-ipad.png",
    "revision": "d99636e003d86d0f5dd7a12fc0144c63"
  },
  {
    "url": "icons/touch-icon-iphone-retina.png",
    "revision": "ed8ebb14cd84e218048d078a4232210a"
  },
  {
    "url": "icons/touch-icon-iphone.png",
    "revision": "96b8a3e39a3fee948f8df76c27bff5c3"
  },
  {
    "url": "index.htm",
    "revision": "e729f03e4a5b8321e1d83c6e4d5ab31a"
  },
  {
    "url": "js/app-builder-audio.js",
    "revision": "4276fca4987ba8ea3717127870f4f44c"
  },
  {
    "url": "js/app-builder-footnotes.js",
    "revision": "134b708bb7c8978cdf0bf1a63049583e"
  },
  {
    "url": "js/app-builder-menus.js",
    "revision": "38119c3a390e610aec209609bf30ccfc"
  },
  {
    "url": "js/app-builder-video.js",
    "revision": "efaf04fe4d2c635684b273e3d049171b"
  },
  {
    "url": "js/book-names.js",
    "revision": "e97e6753108a752275df88d101f370b0"
  },
  {
    "url": "js/jquery-1.11.3.min.js",
    "revision": "895323ed2f7258af4fae2c738c8aea49"
  },
  {
    "url": "js/jquery.tooltipster.min.js",
    "revision": "ff2f685494b400ea2098c79332759a8f"
  },
  {
    "url": "js/popcorn-complete.min.js",
    "revision": "8fbddc624a2f69a176b927a73ad2703d"
  },
  {
    "url": "pwa-main.js",
    "revision": "5630f3086d52ca5e1d63cc6462fcce3d"
  },
  {
    "url": "workbox-config.js",
    "revision": "e12be54ac5dd20622c8e308654daa654"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
